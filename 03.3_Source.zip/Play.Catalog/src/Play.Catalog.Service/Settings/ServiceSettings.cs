namespace Play.Catalog.Service.Settings
{
    public class ServiceSettings
    {
        public string ServiceName { get; init; }
    }
}